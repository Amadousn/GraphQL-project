export const JWT_SECRET = 'votre_clé_secrète_super_sécurisée_123';
